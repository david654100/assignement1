$(document).ready(function(){
    $('#sumbit3').click(function () {
        window.location.replace('signUpPage3.html');

    });

});