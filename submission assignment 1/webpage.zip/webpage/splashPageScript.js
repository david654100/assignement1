$(document).ready(function(){
    $('#loginButton').click(function () {

        window.location.replace("signin.html");
    });

    $('#signUpButton').click(function () {


        window.location.replace("signUpPage.html")
    });




});